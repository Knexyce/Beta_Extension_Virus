// background.js

// Listen for messages from other parts of the extension
chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.action === 'executePythonScript') {
        // Execute Python script
        chrome.scripting.executeScript({
            target: { tabId: sender.tab.id },
            files: ['python_script/script.py']
        }, function(results) {
            if (chrome.runtime.lastError) {
                console.error(chrome.runtime.lastError.message);
                sendResponse({ error: chrome.runtime.lastError.message });
            } else {
                console.log('Python script executed successfully');
                sendResponse({ success: true });
            }
        });
        // Return true to indicate that sendResponse will be called asynchronously
        return true;
    }
});
